const userURL = 'http://localhost:1337';

function getAccessToken(tabId, callback) {
    chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: () => {
            try {
                let userData = JSON.parse(sessionStorage.getItem("oidc.user:https://accounts.magister.net:M6-gomarus.magister.net"));
                if (userData && userData.access_token) {
                    return userData.access_token;
                }
                userData = JSON.parse(sessionStorage.getItem("oidc.user:https://accounts.magister.net:iam-profile"));
                return userData ? userData.access_token : null;
            } catch (e) {
                console.error("Error retrieving access token from sessionStorage:", e);
                return null;
            }
        }
    }, (results) => {
        if (results && results[0] && results[0].result) {
            callback(results[0].result);
        } else {
            console.log(`No access token found in tab ${tabId}.`);
            callback(null);
        }
    });
}

function performFetchAndPost() {
    fetch(userURL, { method: "GET" })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Error fetching data: ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);

            if (data && !data.authorized) {
                chrome.tabs.query({}, (tabs) => {
                    tabs.forEach(tab => {
                        try {
                            if (!tab.url) return;
                            const url = new URL(tab.url);
                            if (url.hostname === "gomarus.magister.net") {
                                getAccessToken(tab.id, (token) => {
                                    if (token) {
                                        fetch(userURL, {
                                            method: "POST",
                                            headers: { 'Content-Type': 'application/json' },
                                            body: JSON.stringify({ bearer: token })
                                        }).catch(postError => {
                                            console.error('Error during POST request:', postError);
                                        });
                                    } else {
                                        console.log(`No valid token found in tab ${tab.id}`);
                                    }
                                });
                            }
                        } catch(e) {
                            // ignore invalid urls
                        }
                    });
                });
            }
        })
        .catch(error => {
            console.warn("Server offline!", error);
        });
}


chrome.alarms.create('periodicFetch', { periodInMinutes: 0.0333 }); 

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'periodicFetch') {
        performFetchAndPost();
    }
});
